! To customize a script, copy it to the main directory (above), otherwise not !

Content
-------
Bas2wav		SHARP BASIC ASCII source text file to playable wave file
BasUwav		SHARP BASIC UTF-8 source (and codepoints) file to wave file
BasKwav		SHARP BASIC source, keywords (and codepoints) file to wave file
Bas2tap		SHARP BASIC source text file to O2S emulator tap file
Bas2bin		SHARP BASIC source file to emulator bin file (with endmark)
Bas2PkG 	SHARP BASIC source file to Pokecom GO load BASIC file

Bas2Asc		BASIC source to ASCII file for serial transmission, no wave 
BasAwav		BASIC with ASCII format to wave file (PC-1600, PC-E and newer)
BasTwav		BASIC with Text mode to wave file (PC-1350 and some newer)
Bas2stw		BASIC file to SuperTape wave (PC-1500), see LISTINGS\SuperTape

Casl2wav	CASL or CAP-X assembler source to TXT-IMG or ASC-BAS wave file
AsmCwav		Pocket assembler/C source text to TXT-IMG or ASC-BAS wave file
Asm8wav		Pocket Z80 assembler source to TXT-IMG or ASC-BAS wave file
Asm5wav		PC-MACRO assembler source text to PC-1500 BASIC wave file

Dat2Wav		Binary special data to playable wave file (PC-1210-1600)
Dat2tap		Binary special data to O2S emulator tap file (PC-1210-1600)
Dasc2Wav	ASCII data format to playable wave file (PC-1600, PC-E/G )
Def2Wav		Definable keys binary (def) to wave file (PC-1500 BAS84)

Img2Wav		Binary BASIC image (img) to playable wave file
img2bas		Binary BASIC image or SuperTape ST file to an editable text

Ihx2Wav		Intel Hex Ascii file to a playable wave file for CLOAD M
MC2Wav		SHARP Binary file (bin, code or data) to a playable wave file
MC2tap		SHARP Binary file (bin, code or data) to O2S emulator tap file

Rsv2Wav		ReSerVable keys binary block (rsv) to playable wave file
Rsv2tap		ReSerVable keys binary block (rsv) to emulator O2S tap file

Shc2Wav		Transfile PC binary to playable wave file (PC-1245-1475)
tap2bas		O2S emulator tap file to an editable BASIC text file
Tap2img		O2S emulator tap file to a binary BASIC image file
Tap2shc		O2S emulator tap file to a Transfile PC binary file
Txt2Wav		SHARP BASIC Text mode image file to a playable wave file

Air2bas		Wave file with BASIC image from microphone to SHARP BASIC text
Cas2bas		Wave file with BASIC image from tape to SHARP BASIC text file

Wav2bas		Wave file with BASIC image to an editable SHARP BASIC text file
WavUbas		Wave file with BASIC image to an editable SHARP BASIC utf8 text
WavEbas		Wave file with BASIC image of PC-E500, that was running before
		CSAVE, to editable text file (two stage mode)
Wav2c		Wave file to an C text file (G8)
Wav2asm		Wave file to an Assembler text (E2/G8, others uncommented only)

Wav2Dasc	Wave file with ASCII data to an ASCII data file (PC-1600/E/G)
Wav2dat		Wave file with binary special data file (dat, PC-1210-1600)
Wav2def		Wave file with definable keys binary block to image file (def)

Wav2imb		Wave file with BASIC image to to binary image file, 
		one binary block mode (if other code included)
Wav2img		Wave file with BASIC image to to binary image file, 
		line by line mode (if image contains only BASIC code)

Wav2mc		Wave file with binary file (code or data) to a image file (bin)
Wav2rsv		Wave file with ReSerVable keys binary block to image file (rsv)
Wav2shc		Wave file to Transfile PC binary file (shc)

Wav2tap		Wave file to O2S emulator tap file (no error control)
Wav2wav		Wave file to syntetic wave file (error control, by CFG-file)
