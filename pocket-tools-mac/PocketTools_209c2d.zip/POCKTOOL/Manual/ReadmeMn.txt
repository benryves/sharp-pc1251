For printing purposes, please use the separately hosted files (larger), 
which are not included in this package:

English manual: Pocket_Tools_Manual.pdf
German manual:  Pocket_Tools_Handbuch.pdf
