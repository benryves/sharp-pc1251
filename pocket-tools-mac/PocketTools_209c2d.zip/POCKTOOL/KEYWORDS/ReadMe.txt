This Keyword Definition Files include the token definitions of some popular extensions of PC-1500.

You can use this files with the the Parameters --keywords=KeywordFile of Bas2img and Wav2bin in Pocket Tools 2.1, see also ReadMe.cfg

Thanks to Eric MILLESCAMPS for his idea and the Key Files

--

The Codepoints Definition Files include the UTF-8 special Chars definitions for newer series with --codepoints=CodepointsFile 
for Bas2img (BasUWav) and Wav2bin (WavUbas).

