/* Add CMT.C for PC-850V(S), Original author: youtube/KOJISAN7 */

void main()
{
 FILE *fpi,*fpo;
 char s[256]="";
 char fi[80]="";
 printf("Filename <T>.DAT=");
 gets (fi);
 if(strlen(fi)==0) 
    strcpy (fi,"T");
 fpi=fopen(strcat(
    fi,".DAT"),"r");
 fpo=fopen(
     "CMT.DAT","w");

 while(feof(fpi)==0) {
  fgets(s, 256, fpi);
  if (s[0] == '\'')
   fprintf(fpo,"%s",s);
  else {
   fprintf(fpo,"'%s",s);
   printf("'%s", s);
  }
 }
 fclose(fpi);
 fclose(fpo);
}
[EOF]

/* Pocket Computer PC-G850V(S) text file recording
   http://www.youtube.com/watch?v=jEO4F8AVtMc
   modified for: 
   Pocket Tools for SHARP Pocket Computers 
   use AsmCwav.cmd */