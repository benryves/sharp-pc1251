For vintage computing only, not for commercial use, no warranty!

This software is based on the first SuperTape version for PC-1500, published by c't 
There exist another advanced version on cassette tapes, selled from Fischel Verlag


SuperTape for PC-1500 Installation and Use


1. Clear all and free memory space
	[Mode] Pro, for PC-1500:	
	CE-155 NEW 15244 (mit Merge 15294)

	CE-151 NEW 17292 (mit Merge 17342)
	CE-159 NEW  9100 (mit Merge  9150)
	CE-160 NEW   908 (mit Merge   958)
	PC-1500A NEW (0)


2. Use the installation programm SUPERTAPE.BAS
   or load binary programm  with CLOAD M (Address included, Length 711 + 50)
    Use/see MC2Wav.cmd (how)to make wav file from bin file



3. [Shift] [Mode] Reserve, Keys F1-F3 load with CLOAD 	(SuperTapeKeys.wav)
    Use/see Rsv2Wav.cmd (how)to make wav file from rsv file


4. Use

!!! SET C$ correctly FIRST and after NEW or you have to reset your PC-1500(A) !!!

	CE-155	Load address &38C5

	FSAVE 	F1: CALL &39E1,C$@	Name in C$
	FVERIFY	F2: CALL &3A32,C$@
	FLOAD	F3: CALL &3A37,C$@	
	Option
	FMERGE	F5: CALL &3B8C,C$@	

	CE-151/PC-1500	Load address &40C5

	FSAVE 	F1: CALL &41E1,C$@	Name in C$
	FVERIFY	F2: CALL &4232,C$@
	FLOAD	F3: CALL &4237,C$@	
	Option
	FMERGE	F5: CALL &438C,C$@	

	CE-159	Load address &20C5

	FSAVE 	F1: CALL &21E1,C$@	Name in C$
	FVERIFY	F2: CALL &2232,C$@
	FLOAD	F3: CALL &2237,C$@	
	Option
	FMERGE	F5: CALL &238C,C$@	

	CE-160/1 Load address &00C5

	FSAVE 	F1: CALL &01E1,C$@	Name in C$
	FVERIFY	F2: CALL &0232,C$@
	FLOAD	F3: CALL &0237,C$@	
	Option
	FMERGE	F5: CALL &038C,C$@	

	PC-1500A Load address &7C01

	FSAVE 	F1: CALL &7D1D,C$@	Name in C$
	FVERIFY	F2: CALL &7D6E,C$@
	FLOAD	F3: CALL &7D73,C$@	
	Option
	FMERGE	F5: CALL &7EC8,C$@	


Copyright / Author see: Heise Verlag, ct 85/3 (84/4), Fischel 9/85
