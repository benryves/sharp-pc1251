Pocket Tools for SHARP Pocket Computer, Version 2.09 c2d, 06.01.2021
Menu with Windows scripts and Linux scripts (see Linux README)

Install for Windows
-------------------

1. Extract the package to a directory (no spaces) or to a mobile stick.
   Scripts used have to be put in the main directory or scripts.win

2. Read the Pocket Tools manual! For printing please use separate files.

3. Replace the menu PStart.xml with your language version, if available.

4. If you need not only BAS files, then you need more scripts from 
   Scripts.win and you can integrate these into the PStart menu.

   e.g. WavEbas.cmd : Convert Wave file with an image of PC-E500 to text

5. Install a source code editor, an audio editor and customize PStart.

6. Adapt PStart to your applications and paths.
   Create links to PStart or the cmd files on your desktop or elsewhere.

7. Edit global settings in SHARPSET.BAT

   - Uncomment or add our SHARP PC type (without "PC-")
   - Change all variables to match your directories and editors.


Using Pocket Tools scripts
--------------------------

Dont use SPaCes in all file or path names, use underscore "_" !
Leading minus sign are not allowed in filenames.

Variants for use

A) Start a cmd-script directly or from desktop link or from the PStart Menu
   to activate the file-open dialog

B) Drag a file (BAS, WAV and what have you) on the appropriate cmd-script
   or Windows desktop (start menu) link

C) Start a cmd-script from a Pocket Tools console window with more parameters,
   use first parameter for the filename or ? to activate the file-open dialog

bas2wav.cmd	convert a SHARP BASIC text file to a wave file
wav2bas.cmd	convert a wave file to an editable BASIC text file

Some scripts also use an .ADR (.CAL) or now a parameter file (.CFG).

Download links
--------------
New version	http://www.peil-partner.de/ifhe.de/sharp/
Other Versions	http://pocket.free.fr/html/soft/pocket-tools_e.html

Newest version of FileToOpen.exe you can get with wfile.zip from: 
http://www.horstmuc.de/wcon.htm and put it in this directory
Newest version of PStart Menu: http://www.pegtop.net/start/
