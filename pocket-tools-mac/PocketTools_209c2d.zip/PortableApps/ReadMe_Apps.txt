Download the portable applications yourself and unpack them here - see Links folder.

1. Install Audacity

2. Install a Source code editor (PSPad portable recommended)
   Install the SHARP Pocket BASIC Syntax Highlighter and Context file

3. HEXeditor optional, if you do not want to use PSPad for it

4. Adjust the settings of PStart menu to your file structure.

5. Adjust the Pocket Tools settings in the SHARPSET file.
